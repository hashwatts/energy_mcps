"""One-time OAuth consent flow. Prints a refresh token for GOOGLE_REFRESH_TOKEN.

Usage:
    export GOOGLE_CLIENT_ID=...  GOOGLE_CLIENT_SECRET=...
    python auth_helper.py

Opens a browser, asks you to approve read-only Gmail access, then prints the refresh token.
Nothing is written to disk. Requested scope is gmail.readonly only.
"""

import os
import sys

from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]


def main() -> int:
    client_id = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
    client_secret = os.environ.get("GOOGLE_CLIENT_SECRET", "").strip()
    if not client_id or not client_secret:
        print("Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET first.", file=sys.stderr)
        return 1

    client_config = {
        "installed": {
            "client_id": client_id,
            "client_secret": client_secret,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": ["http://localhost"],
        }
    }
    flow = InstalledAppFlow.from_client_config(client_config, scopes=SCOPES)
    # prompt=consent forces Google to issue a refresh token even if one was issued before.
    creds = flow.run_local_server(port=0, access_type="offline", prompt="consent", open_browser=True)

    if not creds.refresh_token:
        print("No refresh token returned. Revoke the app at myaccount.google.com/permissions and retry.", file=sys.stderr)
        return 1

    granted = set(creds.scopes or [])
    if granted - set(SCOPES):
        print(f"WARNING: granted scopes exceed gmail.readonly: {sorted(granted)}", file=sys.stderr)

    print("\nAdd this to your environment (do not commit it):\n")
    print(f"GOOGLE_REFRESH_TOKEN={creds.refresh_token}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
