"""Thin read-only wrapper around the Gmail API.

Everything here is synchronous; server.py runs it in a worker thread with a timeout.
Secrets are read from the environment and never logged.
"""

from __future__ import annotations

import base64
import logging
import os
from dataclasses import dataclass, asdict
from email.utils import parseaddr
from typing import Any

import httplib2
from google.oauth2.credentials import Credentials
from google_auth_httplib2 import AuthorizedHttp
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

log = logging.getLogger("gmail_client")

SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]
TOKEN_URI = "https://oauth2.googleapis.com/token"

MAX_ATTACHMENT_BYTES = int(os.environ.get("MAX_ATTACHMENT_BYTES", str(10 * 1024 * 1024)))
MAX_HTML_BYTES = int(os.environ.get("MAX_HTML_BYTES", str(2 * 1024 * 1024)))
HTTP_TIMEOUT_SECONDS = int(os.environ.get("HTTP_TIMEOUT_SECONDS", "30"))

# Synthetic attachment id prefix for parts whose bytes are embedded in the message
# (Gmail only issues attachmentId for larger parts).
INLINE_PART_PREFIX = "part:"


class GmailError(Exception):
    """User-facing error. Message must not contain secrets."""


@dataclass
class AttachmentInfo:
    partId: str
    filename: str
    mimeType: str
    size: int
    attachmentId: str
    contentId: str | None
    isInline: bool


# ---------------------------------------------------------------------------
# Credentials and service
# ---------------------------------------------------------------------------

def _require_env(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise GmailError(f"Server misconfigured: environment variable {name} is not set.")
    return value


def build_service():
    creds = Credentials(
        token=None,
        refresh_token=_require_env("GOOGLE_REFRESH_TOKEN"),
        token_uri=TOKEN_URI,
        client_id=_require_env("GOOGLE_CLIENT_ID"),
        client_secret=_require_env("GOOGLE_CLIENT_SECRET"),
        scopes=SCOPES,
    )
    http = AuthorizedHttp(creds, http=httplib2.Http(timeout=HTTP_TIMEOUT_SECONDS))
    return build("gmail", "v1", http=http, cache_discovery=False)


def _call(request):
    """Execute a googleapiclient request, mapping errors to GmailError."""
    try:
        return request.execute()
    except HttpError as e:
        status = getattr(e, "status_code", None) or getattr(e.resp, "status", "?")
        if status == 404:
            raise GmailError("Message or attachment not found (404).") from None
        if status in (401, 403):
            raise GmailError(
                f"Gmail API refused the request ({status}). Check the refresh token and that "
                "the Gmail API is enabled for the OAuth client's project."
            ) from None
        raise GmailError(f"Gmail API error (HTTP {status}).") from None
    except Exception as e:  # network, timeout, decode
        raise GmailError(f"Gmail request failed: {type(e).__name__}.") from None


# ---------------------------------------------------------------------------
# Allowlist
# ---------------------------------------------------------------------------

def allowed_senders() -> list[str]:
    raw = os.environ.get("ALLOWED_SENDERS", "")
    return [s.strip().lower().lstrip("@") for s in raw.split(",") if s.strip()]


def sender_allowed(from_header: str) -> bool:
    rules = allowed_senders()
    if not rules:
        return True
    _, addr = parseaddr(from_header or "")
    addr = addr.lower()
    if "@" not in addr:
        return False
    domain = addr.split("@", 1)[1]
    for rule in rules:
        if "@" in rule:
            if addr == rule:
                return True
        elif domain == rule or domain.endswith("." + rule):
            return True
    return False


def enforce_allowlist(headers: dict[str, str]) -> None:
    if not sender_allowed(headers.get("from", "")):
        raise GmailError(
            "Refused: message sender is not in ALLOWED_SENDERS. "
            "No content is returned for messages outside the allowlist."
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def b64url_decode(data: str) -> bytes:
    data = data or ""
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))


def header_map(headers: list[dict[str, str]] | None) -> dict[str, str]:
    return {h.get("name", "").lower(): h.get("value", "") for h in (headers or [])}


def _iter_parts(payload: dict[str, Any]):
    """Depth-first walk over all MIME parts, including the top-level payload."""
    stack = [payload]
    while stack:
        part = stack.pop()
        yield part
        for child in reversed(part.get("parts", []) or []):
            stack.append(child)


def _clean_cid(value: str | None) -> str | None:
    if not value:
        return None
    return value.strip().strip("<>").strip() or None


# ---------------------------------------------------------------------------
# Public operations
# ---------------------------------------------------------------------------

def get_message(service, message_id: str, fmt: str = "full") -> dict[str, Any]:
    if not message_id or not message_id.strip():
        raise GmailError("message_id is required.")
    return _call(service.users().messages().get(userId="me", id=message_id.strip(), format=fmt))


def message_headers(msg: dict[str, Any]) -> dict[str, str]:
    return header_map(msg.get("payload", {}).get("headers"))


def list_attachments(msg: dict[str, Any]) -> list[AttachmentInfo]:
    out: list[AttachmentInfo] = []
    for part in _iter_parts(msg.get("payload", {})):
        body = part.get("body", {}) or {}
        mime = (part.get("mimeType") or "").lower()
        filename = part.get("filename") or ""
        hdrs = header_map(part.get("headers"))
        cid = _clean_cid(hdrs.get("content-id"))
        disposition = (hdrs.get("content-disposition") or "").lower()
        is_inline = disposition.startswith("inline") or (cid is not None and mime.startswith("image/"))

        # Skip the message text itself and container parts.
        if mime.startswith("multipart/"):
            continue
        if not filename and not cid and not disposition.startswith("attachment"):
            continue

        attachment_id = body.get("attachmentId")
        if not attachment_id:
            if not body.get("data"):
                continue
            attachment_id = INLINE_PART_PREFIX + str(part.get("partId", ""))

        out.append(
            AttachmentInfo(
                partId=str(part.get("partId", "")),
                filename=filename,
                mimeType=mime or "application/octet-stream",
                size=int(body.get("size") or 0),
                attachmentId=attachment_id,
                contentId=cid,
                isInline=bool(is_inline),
            )
        )
    return out


def find_attachment(msg: dict[str, Any], attachment_id: str) -> AttachmentInfo | None:
    for a in list_attachments(msg):
        if a.attachmentId == attachment_id:
            return a
    return None


def download_attachment(service, msg: dict[str, Any], attachment_id: str) -> tuple[AttachmentInfo, bytes]:
    if not attachment_id or not attachment_id.strip():
        raise GmailError("attachment_id is required.")
    attachment_id = attachment_id.strip()
    info = find_attachment(msg, attachment_id)
    if info is None:
        raise GmailError("attachment_id not found on this message. Call list_attachments first.")
    if info.size > MAX_ATTACHMENT_BYTES:
        raise GmailError(
            f"Attachment is {info.size} bytes, over the {MAX_ATTACHMENT_BYTES} byte limit."
        )

    if attachment_id.startswith(INLINE_PART_PREFIX):
        part_id = attachment_id[len(INLINE_PART_PREFIX):]
        for part in _iter_parts(msg.get("payload", {})):
            if str(part.get("partId", "")) == part_id:
                data = b64url_decode((part.get("body") or {}).get("data", ""))
                break
        else:
            raise GmailError("Inline part not found.")
    else:
        resp = _call(
            service.users().messages().attachments().get(
                userId="me", messageId=msg["id"], id=attachment_id
            )
        )
        data = b64url_decode(resp.get("data", ""))

    if len(data) > MAX_ATTACHMENT_BYTES:
        raise GmailError(f"Downloaded attachment exceeds the {MAX_ATTACHMENT_BYTES} byte limit.")
    return info, data


def get_html_body(msg: dict[str, Any]) -> tuple[str, str]:
    """Return (mimeType, body). Prefers text/html, falls back to text/plain."""
    html: str | None = None
    plain: str | None = None
    for part in _iter_parts(msg.get("payload", {})):
        mime = (part.get("mimeType") or "").lower()
        data = (part.get("body") or {}).get("data")
        if not data or part.get("filename"):
            continue
        if mime == "text/html" and html is None:
            html = b64url_decode(data).decode("utf-8", errors="replace")
        elif mime == "text/plain" and plain is None:
            plain = b64url_decode(data).decode("utf-8", errors="replace")
    if html is not None:
        body, mime = html, "text/html"
    elif plain is not None:
        body, mime = plain, "text/plain"
    else:
        raise GmailError("Message has no text/html or text/plain body part.")
    if len(body.encode("utf-8")) > MAX_HTML_BYTES:
        body = body[:MAX_HTML_BYTES] + "\n<!-- truncated by server size limit -->"
    return mime, body


def search(service, query: str, max_results: int) -> list[dict[str, Any]]:
    if not query or not query.strip():
        raise GmailError("query is required.")
    max_results = max(1, min(int(max_results or 10), 50))
    listing = _call(service.users().messages().list(userId="me", q=query, maxResults=max_results))
    ids = [m["id"] for m in listing.get("messages", []) or []]
    if not ids:
        return []

    # Second cheap list call to learn which of these carry attachments.
    with_att = _call(
        service.users().messages().list(
            userId="me", q=f"({query}) has:attachment", maxResults=max_results
        )
    )
    att_ids = {m["id"] for m in with_att.get("messages", []) or []}

    results = []
    for mid in ids:
        meta = _call(
            service.users().messages().get(
                userId="me", id=mid, format="metadata",
                metadataHeaders=["From", "Subject", "Date"],
            )
        )
        h = message_headers(meta)
        if not sender_allowed(h.get("from", "")):
            continue
        results.append(
            {
                "id": meta["id"],
                "threadId": meta.get("threadId"),
                "from": h.get("from", ""),
                "subject": h.get("subject", ""),
                "date": h.get("date", ""),
                "snippet": meta.get("snippet", ""),
                "hasAttachment": mid in att_ids,
            }
        )
    return results


def attachment_dict(info: AttachmentInfo) -> dict[str, Any]:
    return asdict(info)
