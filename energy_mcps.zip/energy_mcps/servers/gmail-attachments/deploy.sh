#!/usr/bin/env bash
# One-command Cloud Run deploy. Reads secrets from your local .env, stores them in Secret Manager,
# deploys from source. Re-run to update.
set -euo pipefail

: "${GCP_PROJECT:?set GCP_PROJECT}"
REGION="${REGION:-us-central1}"
SERVICE="${SERVICE:-$(basename "$PWD")}"

set -a; source .env; set +a
: "${GOOGLE_CLIENT_ID:?}" "${GOOGLE_CLIENT_SECRET:?}" "${GOOGLE_REFRESH_TOKEN:?}" "${MCP_AUTH_TOKEN:?}"

gcloud config set project "$GCP_PROJECT" >/dev/null
gcloud services enable run.googleapis.com cloudbuild.googleapis.com secretmanager.googleapis.com artifactregistry.googleapis.com >/dev/null

upsert_secret () {
  local name="$1" value="$2"
  if gcloud secrets describe "$name" >/dev/null 2>&1; then
    printf '%s' "$value" | gcloud secrets versions add "$name" --data-file=- >/dev/null
  else
    printf '%s' "$value" | gcloud secrets create "$name" --data-file=- --replication-policy=automatic >/dev/null
  fi
}
upsert_secret ${SERVICE}-client-id "$GOOGLE_CLIENT_ID"
upsert_secret ${SERVICE}-client-secret "$GOOGLE_CLIENT_SECRET"
upsert_secret ${SERVICE}-refresh-token "$GOOGLE_REFRESH_TOKEN"
upsert_secret ${SERVICE}-auth-token "$MCP_AUTH_TOKEN"

PROJECT_NUMBER=$(gcloud projects describe "$GCP_PROJECT" --format='value(projectNumber)')
SA="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"
for s in ${SERVICE}-client-id ${SERVICE}-client-secret ${SERVICE}-refresh-token ${SERVICE}-auth-token; do
  gcloud secrets add-iam-policy-binding "$s" --member="serviceAccount:$SA" --role=roles/secretmanager.secretAccessor >/dev/null
done

gcloud run deploy "$SERVICE" \
  --source . \
  --region "$REGION" \
  --allow-unauthenticated \
  --min-instances 0 --max-instances 2 \
  --memory 1Gi --cpu 1 --timeout 120 \
  --set-env-vars "ALLOWED_SENDERS=${ALLOWED_SENDERS:-},MCP_ALLOW_TOKEN_IN_URL=${MCP_ALLOW_TOKEN_IN_URL:-false}" \
  --set-secrets "GOOGLE_CLIENT_ID=${SERVICE}-client-id:latest,GOOGLE_CLIENT_SECRET=${SERVICE}-client-secret:latest,GOOGLE_REFRESH_TOKEN=${SERVICE}-refresh-token:latest,MCP_AUTH_TOKEN=${SERVICE}-auth-token:latest"

URL=$(gcloud run services describe "$SERVICE" --region "$REGION" --format='value(status.url)')
echo
echo "MCP endpoint: ${URL}/mcp"
echo "Health:       ${URL}/healthz"
echo "Claude Code:  claude mcp add --transport http ${SERVICE} ${URL}/mcp --header \"Authorization: Bearer \$MCP_AUTH_TOKEN\""
