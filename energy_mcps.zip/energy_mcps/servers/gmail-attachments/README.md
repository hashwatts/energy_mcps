# gmail-attachments-mcp

Small read-only MCP server over Gmail. Fills the gap in the stock Gmail connector: it downloads attachments and inline images so Claude can actually look at them.

Transport: streamable HTTP at `/mcp`, protected by a shared bearer token. Scope: `gmail.readonly` only. Four tools, no write actions anywhere.

## Tools

| Tool | Returns |
|---|---|
| `list_attachments(message_id)` | JSON: filename, mimeType, size, attachmentId, contentId, isInline for every part |
| `get_attachment(message_id, attachment_id)` | Images as MCP image content. PDFs as extracted text plus page count; low-text PDFs rendered to PNG per page. Everything else as base64 plus metadata. 10 MB cap. |
| `get_message_html(message_id)` | Raw HTML body (text/plain fallback) for exact link extraction |
| `search_messages(query, max_results)` | Gmail query syntax. id, threadId, from, subject, date, snippet, hasAttachment |

Inline images that Gmail embeds directly in the message (no Gmail attachmentId) get a synthetic id of the form `part:<partId>`. Pass it to `get_attachment` like any other id.

## Safety model

- Scope is `gmail.readonly`. The helper script warns if Google grants anything broader.
- `ALLOWED_SENDERS` (optional): comma-separated addresses and/or domains. Subdomains match a domain rule. When set, every content tool refuses messages from other senders and `search_messages` drops them from results.
- Every text payload is prefixed with an untrusted-content banner, and tool descriptions say the same. The server returns data; it never interprets it.
- Secrets come from env vars only. Nothing is logged except message ids and error class names.
- Hard limits: 10 MB per attachment, 2 MB per HTML body, 30 s per Google call, 60 s per tool call, 10 rendered PDF pages. All adjustable in `.env`.

## Files

```
server.py          FastMCP app, four tools, bearer-auth ASGI middleware, PDF handling
gmail_client.py    Gmail API calls, MIME walking, allowlist
auth_helper.py     One-time consent flow, prints the refresh token
test_server.py     End-to-end test client (image round-trip, optional PDF)
deploy.sh          One-command Cloud Run deploy
Dockerfile, requirements.txt, .env.example
```

## 1. Google Cloud setup (one time)

1. Create or pick a project at console.cloud.google.com. Note the project id.
2. APIs & Services, Library: enable **Gmail API**.
3. APIs & Services, OAuth consent screen:
   - User type **Internal** if your account is on Google Workspace (recommended: no verification, refresh tokens do not expire).
   - If you must use **External**, publish the app to Production after testing. Apps left in Testing status get refresh tokens that expire after 7 days.
   - Add scope `https://www.googleapis.com/auth/gmail.readonly`.
4. APIs & Services, Credentials, Create credentials, **OAuth client ID**, application type **Desktop app**. Copy the client id and secret.

## 2. Get a refresh token

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export GOOGLE_CLIENT_ID=... GOOGLE_CLIENT_SECRET=...
python auth_helper.py
```

A browser opens. Approve read-only access with the mailbox you want exposed. The script prints `GOOGLE_REFRESH_TOKEN=...`. Put it in `.env` (copy from `.env.example`). Never commit `.env`.

Generate the MCP bearer token: `openssl rand -hex 32` and set `MCP_AUTH_TOKEN`.

## 3. Run locally

```bash
set -a; source .env; set +a
python server.py
# http://localhost:8080/mcp     http://localhost:8080/healthz
```

Smoke test without a client:

```bash
curl -i localhost:8080/healthz                           # 200
curl -i -X POST localhost:8080/mcp                       # 401
```

## 4. Test with MCP Inspector (before Claude)

```bash
npx @modelcontextprotocol/inspector
```

In the Inspector UI:
1. Transport: **Streamable HTTP**. URL: `http://localhost:8080/mcp`.
2. Authentication: header name `Authorization`, value `Bearer <MCP_AUTH_TOKEN>` (there is a Bearer Token field; paste the raw token there).
3. Connect. Tools tab should show the four tools.
4. Run `search_messages` with `from:supplier.com has:attachment newer_than:30d` to get a message id.
5. Run `list_attachments` with that id, then `get_attachment` with an `attachmentId`. Image results render inline in the Inspector.

## 5. Automated test

```bash
python test_server.py --url http://localhost:8080/mcp --token "$MCP_AUTH_TOKEN" --message-id <id> [--pdf]
```

Checks tool list, lists attachments, fetches the first inline image (or `--attachment-id`), verifies the base64 decodes to a valid image whose format matches the declared mimeType, writes it to `./out/`. `--pdf` additionally fetches the first PDF and prints page count, text length, and rendered page count. Works against the Cloud Run URL too.

## 6. Deploy to Cloud Run

Why Cloud Run: you already have a Google Cloud project for the Gmail API, `gcloud run deploy --source` builds and ships in one command, you get HTTPS and a stable URL with no load balancer, it scales to zero, and Secret Manager holds the tokens. Fly.io works equally well; Cloud Run just removes one vendor.

```bash
gcloud auth login
GCP_PROJECT=<project-id> ./deploy.sh
```

The script enables the needed APIs, stores the four secrets in Secret Manager, grants the Cloud Run service account access, deploys, and prints the endpoint plus the exact `claude mcp add` command. `--allow-unauthenticated` is intentional: Cloud Run IAM cannot carry our bearer header, so the server does its own auth on every request.

Re-run `./deploy.sh` to roll out changes. Rotate the token by changing `MCP_AUTH_TOKEN` in `.env` and redeploying.

Manual alternative (no script):

```bash
gcloud run deploy gmail-mcp --source . --region us-central1 --allow-unauthenticated \
  --set-env-vars ALLOWED_SENDERS=supplier.com \
  --set-env-vars GOOGLE_CLIENT_ID=...,GOOGLE_CLIENT_SECRET=...,GOOGLE_REFRESH_TOKEN=...,MCP_AUTH_TOKEN=...
```

## 7. Register with Claude

In this repo the routine wiring lives in the root `.mcp.json` and `routines/supplier-810-check.md`.

**Claude Code**

```bash
claude mcp add --transport http gmail-attachments https://<service>.run.app/mcp \
  --header "Authorization: Bearer $MCP_AUTH_TOKEN"
```

Add `--scope project` to write `.mcp.json` for a repo instead of your user config. Check with `/mcp` inside Claude Code.

**claude.ai custom connector**

Settings, Connectors, Add custom connector, URL `https://<service>.run.app/mcp`. Custom connectors authenticate with OAuth or no auth; a static header is only available if your account shows a Request headers section (beta). Two options:

- If you have the headers option: add header `Authorization` with value `Bearer <MCP_AUTH_TOKEN>`, leave client id and secret blank.
- Otherwise set `MCP_ALLOW_TOKEN_IN_URL=true` and use the URL `https://<service>.run.app/t/<MCP_AUTH_TOKEN>/mcp` with no auth. The token then lives in the URL, which is weaker (it can appear in logs). Use a long token, keep `ALLOWED_SENDERS` set, and rotate periodically.

Then enable the connector in a chat via the `+` menu.

## Example agent workflow

1. `search_messages("from:supplier.com subject:810 newer_than:14d", 5)`
2. `list_attachments(<id>)` to find the inline PNG (isInline true, contentId matches the `cid:` in the HTML) and the PDF.
3. `get_attachment(<id>, <png attachmentId>)` and read the "810 amount" column from the image.
4. `get_attachment(<id>, <pdf attachmentId>)` and compare the PDF total to the bill amount.
5. `get_message_html(<id>)` if a link target is needed.

Accuracy note: images are passed through untouched at original resolution. PDFs that are scanned render at 1.5x scale (about 108 dpi); raise `PDF_RENDER_SCALE` to 2.0 for small print.

## Troubleshooting

- `401 unauthorized`: header missing, no `Bearer ` prefix, or token mismatch between client and server.
- `Gmail API refused the request (401/403)`: refresh token revoked or expired (External app in Testing status), or Gmail API not enabled on the client's project. Re-run `auth_helper.py`.
- `Refused: message sender is not in ALLOWED_SENDERS`: working as intended; widen the list or send from an allowed address.
- Cloud Run cold starts take 2 to 4 s. Set `--min-instances 1` in `deploy.sh` if that matters.
