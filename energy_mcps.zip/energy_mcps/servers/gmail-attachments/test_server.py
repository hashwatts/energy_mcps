"""End-to-end test against a running server.

    python test_server.py --url http://localhost:8080/mcp --token "$MCP_AUTH_TOKEN" \
        --message-id 18f0c2a1b3d4e5f6 [--attachment-id ...] [--pdf]

Steps:
  1. tools/list shows the four tools.
  2. list_attachments for the message.
  3. Picks the first inline image (or --attachment-id) and calls get_attachment.
  4. Verifies an ImageContent block came back, base64-decodes it, opens it with Pillow,
     checks the declared mimeType matches the decoded format, saves it to ./out/.
  5. With --pdf: also fetches the first PDF and prints page count / text length / rendered pages.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import io
import json
import sys
from pathlib import Path

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from mcp.types import ImageContent, TextContent
from PIL import Image

PIL_FORMAT_TO_MIME = {"PNG": "image/png", "JPEG": "image/jpeg", "GIF": "image/gif", "WEBP": "image/webp"}


def fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    sys.exit(1)


async def main(args) -> None:
    headers = {"Authorization": f"Bearer {args.token}"}
    async with streamablehttp_client(args.url, headers=headers) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools = {t.name for t in (await session.list_tools()).tools}
            expected = {"list_attachments", "get_attachment", "get_message_html", "search_messages"}
            if not expected <= tools:
                fail(f"missing tools: {expected - tools}")
            print(f"OK  tools present: {sorted(tools)}")

            res = await session.call_tool("list_attachments", {"message_id": args.message_id})
            if res.isError:
                fail(f"list_attachments error: {res.content[0].text}")
            listing = json.loads(res.content[0].text)
            atts = listing["attachments"]
            print(f"OK  list_attachments: {len(atts)} part(s) from {listing['from']!r}")
            for a in atts:
                print(f"    {a['attachmentId'][:24]:<26} {a['mimeType']:<24} {a['size']:>9}  inline={a['isInline']}  cid={a['contentId']}")

            # ---- image round-trip ----
            target = None
            if args.attachment_id:
                target = next((a for a in atts if a["attachmentId"] == args.attachment_id), None)
            else:
                images = [a for a in atts if a["mimeType"].startswith("image/")]
                target = next((a for a in images if a["isInline"]), images[0] if images else None)
            if target is None:
                fail("no image attachment found on this message")

            res = await session.call_tool(
                "get_attachment", {"message_id": args.message_id, "attachment_id": target["attachmentId"]}
            )
            if res.isError:
                fail(f"get_attachment error: {res.content[0].text}")
            img_blocks = [c for c in res.content if isinstance(c, ImageContent)]
            if not img_blocks:
                fail("no ImageContent block returned for image attachment")
            img = img_blocks[0]
            raw = base64.b64decode(img.data, validate=True)
            pil = Image.open(io.BytesIO(raw))
            pil.verify()
            pil = Image.open(io.BytesIO(raw))
            decoded_mime = PIL_FORMAT_TO_MIME.get(pil.format or "")
            if decoded_mime != img.mimeType:
                fail(f"mimeType mismatch: declared {img.mimeType}, decoded {decoded_mime}")

            out_dir = Path("out")
            out_dir.mkdir(exist_ok=True)
            ext = (pil.format or "bin").lower()
            out_path = out_dir / f"{target['attachmentId'][:16].replace(':', '_')}.{ext}"
            out_path.write_bytes(raw)
            print(f"OK  image round-trip: {img.mimeType} {pil.size[0]}x{pil.size[1]} {len(raw)} bytes -> {out_path}")

            # ---- optional PDF ----
            if args.pdf:
                pdf = next((a for a in atts if a["mimeType"] == "application/pdf" or a["filename"].lower().endswith(".pdf")), None)
                if pdf is None:
                    fail("--pdf given but no PDF attachment on this message")
                res = await session.call_tool(
                    "get_attachment", {"message_id": args.message_id, "attachment_id": pdf["attachmentId"]}
                )
                if res.isError:
                    fail(f"get_attachment (pdf) error: {res.content[0].text}")
                text_blocks = [c for c in res.content if isinstance(c, TextContent)]
                img_blocks = [c for c in res.content if isinstance(c, ImageContent)]
                meta_json = text_blocks[0].text.split("\n", 1)[1]  # strip banner line
                meta = json.loads(meta_json.split("\n\n", 1)[0])
                print(f"OK  pdf: pages={meta['pageCount']} textChars={meta['textChars']} renderedPages={len(img_blocks)}")

            print("ALL OK")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--url", default="http://localhost:8080/mcp")
    p.add_argument("--token", required=True)
    p.add_argument("--message-id", required=True)
    p.add_argument("--attachment-id")
    p.add_argument("--pdf", action="store_true")
    asyncio.run(main(p.parse_args()))
