# _template

Starting point for a new server. To add one:

1. `cp -r servers/_template servers/<name>`
2. Replace the `ping` tool in `server.py`. Keep the `BearerAuth` wrapper and `_run` timeout.
3. List extra secrets in `.env.example` and add them to `deploy.sh` (follow the pattern in `servers/gmail-attachments/deploy.sh`).
4. Deploy: `cd servers/<name> && GCP_PROJECT=<id> ./deploy.sh`
5. Add the entry to the root `.mcp.json` with its own `${<NAME>_MCP_TOKEN}` variable, and add that credential to the routine environment.
