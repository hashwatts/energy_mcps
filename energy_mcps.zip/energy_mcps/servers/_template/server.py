"""Template MCP server. Copy this folder, rename, replace the example tool.

Keeps the same shape as every server in this repo:
  streamable HTTP at /mcp, bearer token from MCP_AUTH_TOKEN, /healthz open,
  secrets from env only, every tool wrapped in a timeout.
"""

from __future__ import annotations

import asyncio
import hmac
import logging
import os

import uvicorn
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
log = logging.getLogger("template_mcp")

TOOL_TIMEOUT_SECONDS = float(os.environ.get("TOOL_TIMEOUT_SECONDS", "60"))

mcp = FastMCP("template", instructions="Replace me.", stateless_http=True)


async def _run(fn, *args):
    try:
        return await asyncio.wait_for(asyncio.to_thread(fn, *args), timeout=TOOL_TIMEOUT_SECONDS)
    except asyncio.TimeoutError:
        raise ToolError(f"Timed out after {TOOL_TIMEOUT_SECONDS:.0f}s.") from None


@mcp.tool()
async def ping(text: str = "pong") -> str:
    """Example tool. Echoes text back."""
    return await _run(lambda t: t, text)


class BearerAuth:
    def __init__(self, app, token: str):
        self.app, self.token = app, token.encode()

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        if scope.get("path") == "/healthz":
            return await self._respond(send, 200, b"ok")
        for name, value in scope.get("headers", []):
            if name == b"authorization":
                scheme, _, cred = value.partition(b" ")
                if scheme.lower() == b"bearer" and hmac.compare_digest(cred.strip(), self.token):
                    return await self.app(scope, receive, send)
        return await self._respond(send, 401, b"unauthorized")

    @staticmethod
    async def _respond(send, status, body):
        await send({"type": "http.response.start", "status": status,
                    "headers": [(b"content-type", b"text/plain"), (b"content-length", str(len(body)).encode())]})
        await send({"type": "http.response.body", "body": body})


def build_app():
    token = os.environ.get("MCP_AUTH_TOKEN", "").strip()
    if len(token) < 16:
        raise SystemExit("MCP_AUTH_TOKEN must be set and at least 16 characters.")
    return BearerAuth(mcp.streamable_http_app(), token)


app = build_app()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8080")))
