#!/usr/bin/env bash
# Deploy this folder to Cloud Run. Service name = folder name. Add more secrets as needed.
set -euo pipefail
: "${GCP_PROJECT:?set GCP_PROJECT}"
REGION="${REGION:-us-central1}"
SERVICE="${SERVICE:-$(basename "$PWD")}"
set -a; source .env; set +a
: "${MCP_AUTH_TOKEN:?}"

gcloud config set project "$GCP_PROJECT" >/dev/null
gcloud services enable run.googleapis.com cloudbuild.googleapis.com secretmanager.googleapis.com artifactregistry.googleapis.com >/dev/null
if gcloud secrets describe "${SERVICE}-auth-token" >/dev/null 2>&1; then
  printf '%s' "$MCP_AUTH_TOKEN" | gcloud secrets versions add "${SERVICE}-auth-token" --data-file=- >/dev/null
else
  printf '%s' "$MCP_AUTH_TOKEN" | gcloud secrets create "${SERVICE}-auth-token" --data-file=- --replication-policy=automatic >/dev/null
fi
PROJECT_NUMBER=$(gcloud projects describe "$GCP_PROJECT" --format='value(projectNumber)')
gcloud secrets add-iam-policy-binding "${SERVICE}-auth-token" \
  --member="serviceAccount:${PROJECT_NUMBER}-compute@developer.gserviceaccount.com" --role=roles/secretmanager.secretAccessor >/dev/null

gcloud run deploy "$SERVICE" --source . --region "$REGION" --allow-unauthenticated \
  --min-instances 0 --max-instances 2 --memory 512Mi --timeout 120 \
  --set-secrets "MCP_AUTH_TOKEN=${SERVICE}-auth-token:latest"
URL=$(gcloud run services describe "$SERVICE" --region "$REGION" --format='value(status.url)')
echo "MCP endpoint: ${URL}/mcp"
